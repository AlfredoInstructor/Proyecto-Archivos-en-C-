#include <cstdlib>
#include <iostream>
#include <string.h>
using namespace std;

int main(int argc, char *argv[])
{
    FILE *fptr1;
    FILE *fptr2;
    FILE *fptr3;
    FILE *fptr4;
    FILE *fptr5;
    FILE *fptr6;
    
    char Disco[50]={""};
    char Artistas[50]={""};
    char Empresa[50]={""};
    char Giro[50]={""};
    char Pais[50]={""};
    char Estilo_Musical[50]={""};
    
    
    fptr1 =fopen ("Disco.txt","w");
    fptr2 =fopen ("Artistas.txt","w");
    fptr3 =fopen ("Empresa.txt","w");
    fptr4 =fopen ("Giro.txt","w");
    fptr5 =fopen ("Pais.txt","w");
    fptr6 =fopen ("Estilo_Musical.txt","w");
    
    
   cout<<"\n **************************************************************** \n";
   cout<<"\n BIENVENIDOS al Programa Para Escribir \n";
   cout<<"\n **************************************************************** \n";
   
    cout<<"Ingrese el Disco:";
    cin>>Disco;
    cout<<"Nombre de Artista:";
    cin>>Artistas;
    cout<<"Nombre de Empresa:";
    cin>>Empresa;
    cout<<"Ingrese el Giro:";
    cin>>Giro;
    cout<<"Nombre del Pais:";
    cin>>Pais;
    cout<<"Ingrese Musica:";
    cin>>Estilo_Musical;
    
    fprintf(fptr1,"%s",Disco);
    fprintf(fptr2,"%s",Artistas);
    fprintf(fptr3,"%s",Empresa);
    fprintf(fptr4,"%s",Giro);
    fprintf(fptr5,"%s",Pais);
    fprintf(fptr6,"%s",Estilo_Musical);
    
      cout<<"\n **************************************************************** \n";
    
    
    fclose (fptr1);
    fclose (fptr2);
    fclose (fptr3);
    fclose (fptr4);
    fclose (fptr5);
    fclose (fptr6);
     
     system("PAUSE");
    return EXIT_SUCCESS;
}
