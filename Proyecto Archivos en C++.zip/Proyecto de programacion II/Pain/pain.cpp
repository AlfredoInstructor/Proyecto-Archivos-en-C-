#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char *argv[])
{
    FILE *fptr1;
    FILE *fptr2;
    FILE *fptr3;
    FILE *fptr4;
    FILE *fptr5;
    FILE *fptr6;
    
    
    
    char Disco[50]={""};
    char Artistas[50]={""};
    char Empresa[50]={""};
    char Giro[50]={""};
    char Pais[50]={""};
    char Estilo_Musical[50]={""};
   
   
   fptr1=fopen("Disco.txt","r");
   fptr2=fopen("Artistas.txt","r");
   fptr3=fopen("Empresa.txt","r");
   fptr4=fopen("Giro.txt","r");
   fptr5=fopen("Pais.txt","r");
   fptr6=fopen("Estilo_Musical.txt","r");


   fscanf(fptr1,"%s",Disco);
   fscanf(fptr2,"%s",Artistas);
   fscanf(fptr3,"%s",Empresa);
   fscanf(fptr4,"%s",Giro);
   fscanf(fptr5,"%s",Pais);
   fscanf(fptr6,"%s",Estilo_Musical);
   
   cout<<"\n **************************************************************** \n";
   cout<<"\n BIENVENIDOS al Programa Para Leer \n";
   cout<<"\n **************************************************************** \n";
   
    
  cout<<"\n El contenido del Disco es: \n"<<Disco;
  cout<<"\n _________________________________________________________________ \n"; 
  cout<<"\n El contenido de Artistas es: \n"<<Artistas;
  cout<<"\n _________________________________________________________________ \n";  
  cout<<"\n El contenido de la Empresa es: \n"<<Empresa;
  cout<<"\n _________________________________________________________________ \n";  
  cout<<"\n El contenido del Giro es: \n"<<Giro;
  cout<<"\n _________________________________________________________________ \n";  
  cout<<"\n El contenido del Pais es: \n"<<Pais;
  cout<<"\n _________________________________________________________________ \n";  
  cout<<"\n El contenido del Estilo Muscial es: \n"<<Estilo_Musical;
  cout<<"\n _________________________________________________________________ \n";  
  cout<<"\n \n";
  cout<<"\n ***************************************************************** \n";
  cout<<"\n \n";
     
     
  fclose(fptr1); 
  fclose(fptr2); 
  fclose(fptr3); 
  fclose(fptr4); 
  fclose(fptr5); 
  fclose(fptr6); 
   
    system("PAUSE");
    return EXIT_SUCCESS;
}
